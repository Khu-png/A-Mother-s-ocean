using UnityEngine;

public class CameraController : MonoBehaviour
{
    [SerializeField] private UnityEngine.Camera targetCamera;
    [SerializeField] private SafeArenaSettings safeArena = new SafeArenaSettings();
    private Transform cameraTransform;
    private SpriteRenderer cachedBackground;
    private Transform backgroundTransform;
    private int inspectorLayoutVersion;

    public int LayoutRevision
    {
        get
        {
            unchecked
            {
                int revision = Screen.width;
                revision = revision * 31 + Screen.height;
                revision = revision * 31 + Screen.safeArea.GetHashCode();
                revision = revision * 31 + inspectorLayoutVersion;
                if (targetCamera == null) return revision;
                revision = revision * 31 + targetCamera.orthographicSize.GetHashCode();
                return revision * 31 + targetCamera.aspect.GetHashCode();
            }
        }
    }

    void Awake()
    {
        if (targetCamera != null) cameraTransform = targetCamera.transform;
    }

    void OnValidate()
    {
        inspectorLayoutVersion++;
    }

    public void FitBackground(SpriteRenderer background)
    {
        if (targetCamera == null || background == null || background.sprite == null) return;
        if (cameraTransform == null) cameraTransform = targetCamera.transform;
        if (cachedBackground != background)
        {
            cachedBackground = background;
            backgroundTransform = background.transform;
        }

        float height = targetCamera.orthographicSize * 2f;
        Vector2 spriteSize = background.sprite.bounds.size;
        float scale = Mathf.Max(height / spriteSize.y, height * targetCamera.aspect / spriteSize.x) * 1.02f;
        Transform view = backgroundTransform;
        Vector3 worldScale = view.lossyScale;
        if (Mathf.Abs(worldScale.x) < 0.0001f || Mathf.Abs(worldScale.y) < 0.0001f) return;
        view.localScale = new Vector3(view.localScale.x * scale / Mathf.Abs(worldScale.x),
            view.localScale.y * scale / Mathf.Abs(worldScale.y), view.localScale.z);
        view.position = cameraTransform.position + cameraTransform.forward * 20f;
        view.rotation = cameraTransform.rotation;
    }

    public SafeArenaWorldLayout CalculateGridLayout(int columns, int rows, float boardZ)
    {
        if (targetCamera == null) return default;
        SafeArenaScreenLayout screenLayout = SafeArenaCalculator.Calculate(
            Screen.safeArea, safeArena, columns, rows);
        float pixelHeight = Mathf.Max(1f, targetCamera.pixelHeight);
        float worldPerPixel = targetCamera.orthographicSize * 2f / pixelHeight;
        float depth = Mathf.Abs(boardZ - CameraTransform().position.z);
        Vector3 screenCenter = new Vector3(screenLayout.BoardCenter.x,
            screenLayout.BoardCenter.y, depth);
        Vector3 worldCenter = targetCamera.ScreenToWorldPoint(screenCenter);
        return new SafeArenaWorldLayout(worldCenter,
            screenLayout.CellSize * worldPerPixel,
            screenLayout.Spacing * worldPerPixel);
    }

    private Transform CameraTransform()
    {
        if (cameraTransform == null && targetCamera != null) cameraTransform = targetCamera.transform;
        return cameraTransform;
    }

#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        if (Application.isPlaying || targetCamera == null || !safeArena.ShowEditorPreview) return;
        SafeArenaScreenLayout layout = SafeArenaCalculator.Calculate(Screen.safeArea, safeArena, 1, 1);
        DrawScreenRect(layout.Arena, safeArena.PreviewColor);
        Color usableColor = safeArena.PreviewColor;
        usableColor.a *= 0.55f;
        DrawScreenRect(layout.UsableArea, usableColor);
    }

    private void DrawScreenRect(Rect screenRect, Color color)
    {
        float depth = Mathf.Abs(CameraTransform().position.z);
        Vector3 minimum = targetCamera.ScreenToWorldPoint(
            new Vector3(screenRect.xMin, screenRect.yMin, depth));
        Vector3 maximum = targetCamera.ScreenToWorldPoint(
            new Vector3(screenRect.xMax, screenRect.yMax, depth));
        Vector3 center = (minimum + maximum) * 0.5f;
        Vector3 size = new Vector3(maximum.x - minimum.x, maximum.y - minimum.y, 0f);
        Gizmos.color = color;
        Gizmos.DrawWireCube(center, size);
    }
#endif
}
